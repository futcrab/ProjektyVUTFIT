#include <libavformat/avformat.h>

int main() {
    av_register_all();

    return 0;
}
